package com.example.myapp2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
